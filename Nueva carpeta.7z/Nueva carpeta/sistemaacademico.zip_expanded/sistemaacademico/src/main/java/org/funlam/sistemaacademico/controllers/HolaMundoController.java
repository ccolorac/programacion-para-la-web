package org.funlam.sistemaacademico.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/HolaMundo")
public class HolaMundoController {

	@GetMapping("/Saludar")
	public String saludar() {
		return "saludar";
	}
	
	@GetMapping("/Despedir")
	public String despedir() {
		return "despedir";
	}
	
}
