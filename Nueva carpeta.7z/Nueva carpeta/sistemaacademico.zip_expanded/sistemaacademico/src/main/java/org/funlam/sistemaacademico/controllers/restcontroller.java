package org.funlam.sistemaacademico.controllers;

public class restcontroller {

}
