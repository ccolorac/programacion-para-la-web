package org.funlam.sistemaacademico.controllers;

import org.funlam.sistemaacademico.entities.Saludo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Api/HolaMundo")
public class HolaMundoRestController {
	
	@GetMapping("/Saludar")
	public Saludo saludar() {
		return new Saludo("Hola mundo");
	}
	
	@GetMapping("/Despedir")
	public Saludo despedir() {
		return new Saludo("Adiós mundo");
	}
}
