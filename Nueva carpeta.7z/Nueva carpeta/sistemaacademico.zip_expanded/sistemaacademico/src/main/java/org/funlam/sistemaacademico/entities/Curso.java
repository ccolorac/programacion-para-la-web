package org.funlam.sistemaacademico.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "curso")
public class Curso {
	
	@Id	
	@GeneratedValue
	@Column(name="codigo")
	private int id;

	private String nombre;
	
	private int duracionHoras;
	public Curso(int id, String nombre, int duracionHoras) {
		this.id = id;
		this.nombre = nombre;
		this.duracionHoras = duracionHoras;
	}
	public Curso() {
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getDuracionHoras() {
		return duracionHoras;
	}
	public void setDuracionHoras(int duracionHoras) {
		this.duracionHoras = duracionHoras;
	}
 	
}
