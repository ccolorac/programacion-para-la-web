package org.funlam.sistemaacademico.controllers;



import java.util.List;
import java.util.Optional;

import org.funlam.sistemaacademico.entities.Curso;
import org.funlam.sistemaacademico.repository.CursoJPARepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/curso")
public class CursoController {
	
	@Autowired
	@Qualifier("cursoJPARepository")
	private CursoJPARepository cursoJpa;
	
	@RequestMapping(method= RequestMethod.GET,
	produces= MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> consultar(){
		return cursoJpa.findAll();
	}
	
	@RequestMapping(
			value = "/{idCurso}",
			method= RequestMethod.GET,
	produces= MediaType.APPLICATION_JSON_VALUE)
	public Optional<Curso> 
			consultarPorId(@PathVariable int idCurso){
		return cursoJpa.findById(idCurso);
	}
	
	
	@RequestMapping(method= RequestMethod.POST,
	produces= MediaType.APPLICATION_JSON_VALUE)
	public Curso
			crearCurso(@RequestBody Curso curso){
		cursoJpa.save(curso);
		return curso;
	}
	
	@RequestMapping(method= RequestMethod.PUT,
	produces= MediaType.APPLICATION_JSON_VALUE)
	public Curso
	   editarCurso(@RequestBody Curso curso){
		cursoJpa.save(curso);
		return curso;
	}
	
	
	@RequestMapping(value = "/{idCurso}", method= RequestMethod.DELETE,
	produces= MediaType.APPLICATION_JSON_VALUE)
	public boolean
			eliminarPorId(@PathVariable int idCurso){
		cursoJpa.deleteById(idCurso);
		return true;
		
	}
	
	
	
	
	
	

}
