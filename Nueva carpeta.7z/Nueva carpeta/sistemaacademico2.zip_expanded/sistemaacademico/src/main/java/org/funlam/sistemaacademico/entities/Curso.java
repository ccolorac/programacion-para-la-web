package org.funlam.sistemaacademico.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "curso")
public class Curso {
	
	@Id	
	@GeneratedValue
	@Column(name="codigo")
	private int id;

	private String nombre;
	private int duracionHoras;

	
	
}
